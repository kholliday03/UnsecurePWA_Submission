import sqlite3 as sql
import time
import random
from werkzeug.security import generate_password_hash, check_password_hash

def get_db():   # Function to retrieve a database row to replace the cursor function - it was not working as intended 
    db = sql.connect('database_files/database.db') 
    db.row_factory = sql.Row 
    return db

def insertUser(username, password, DoB):
    db = get_db()
    db.execute(
        "INSERT INTO users (username, password, dateOfBirth) VALUES (?,?,?)", # Parametrisation - Already done by 'The Unsecure PWA Company'
        (username, generate_password_hash(password), DoB),  # Hashes the password before entering into database
    )
    db.commit()


def retrieveUsers(username, password):
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone() # Replaced sqlite3.Cursor object with sqlite3.Row object
    # Line 22 - parametrised query - prevents SQL injection
    try:
        if check_password_hash(user["password"], password): # Checking password hash
            # Plain text log of visitor count as requested by Unsecure PWA management
            with open("visitor_log.txt", "r") as file:
                number = int(file.read().strip())
                number += 1
            with open("visitor_log.txt", "w") as file:
                file.write(str(number))
            # Simulate response time of heavy app for testing purposes
            time.sleep(random.randint(80, 90) / 1000)
            if user == None:
                return False, False
            else:
                return True, user
    except Exception:
        return False, False
    return False, False


def insertFeedback(feedback):
    db = get_db()
    db.execute(f"INSERT INTO feedback (feedback) VALUES (?)", (feedback,))  # Parametrisation - SQL injection fix
    db.commit()
    return

def listFeedback():
    db = get_db()
    data = db.execute("SELECT * FROM feedback").fetchall()
    f = open("templates/partials/success_feedback.html", "w")
    for row in data:
        f.write("<p>\n")
        f.write(f"{row[1]}\n")
        f.write("</p>\n")
    f.close()
