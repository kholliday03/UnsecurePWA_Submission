from flask import Flask
from flask import render_template
from flask import request
from flask import redirect, url_for # Added url_for library
import user_management as dbHandler
from flask import session   # Added session library

# Code snippet for logging a message
# app.logger.critical("message")

app = Flask(__name__)

app.secret_key = "AT2-SSA-SftEng"   # Required to create sessions

@app.route("/success.html", methods=["POST", "GET", "PUT", "PATCH", "DELETE"])
def addFeedback():
    if request.method == "POST":
        feedback = request.form["feedback"]
        dbHandler.insertFeedback(feedback)
        dbHandler.listFeedback()
        return redirect(url_for("addFeedback")) # Ensures redirects only go to valid routes
    else:
        dbHandler.listFeedback()
        return render_template("success.html")


@app.route("/signup.html", methods=["POST", "GET", "PUT", "PATCH", "DELETE"])
def signup():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        DoB = request.form["dob"]
        dbHandler.insertUser(username, password, DoB)
        return redirect(url_for("home"))    # Ensures redirects only go to valid routes
    else:
        return render_template("signup.html")


@app.route("/index.html", methods=["POST", "GET", "PUT", "PATCH", "DELETE"])
@app.route("/", methods=["POST", "GET"])
def home():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        isLoggedIn, user = dbHandler.retrieveUsers(username, password)  # Added user variable to create session
        if isLoggedIn:
            session.clear() # Session data cleared
            session["user_id"] = user["id"]
            session["username"] = user["username"]  # Session added for logged in users
            dbHandler.listFeedback()
            return redirect(url_for("addFeedback")) # Ensures redirects only go to valid routes
        else:
            return render_template("index.html")
    else:
        return render_template("index.html")

@app.route("/logout")   # Added logout function to assist in the prevention of invalid forwarding and redirecting 
def logout():
    session.pop('user_id', default=None)    # Clearing session data
    session.pop('username', default=None)
    return redirect(url_for("home"))    # Ensures redirects only go to valid routes

if __name__ == "__main__":
    app.config["TEMPLATES_AUTO_RELOAD"] = True
    app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0
    app.run(debug=True, host="0.0.0.0", port=5000)
